const API_URL = "http://127.0.0.1:5000";

async function obterConsultas() {
    try {
        const resposta = await fetch(`${API_URL}/consultas`);
        if (!resposta.ok) throw new Error("Erro na resposta do servidor");
        return await resposta.json();
    } catch (erro) {
        console.error("Falha ao buscar consultas do servidor:", erro);
        return [];
    }
}

async function initPrioridades() {
    const tbody = document.querySelector("#tabelaPrioridades tbody");
    if (!tbody) return;

    // 1. Feedback visual de carregamento inicial
    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; padding:20px; color:#666;"><i class="fa fa-spinner fa-spin"></i> A carregar fila de triagem...</td></tr>`;

    // 2. Procura os dados no servidor Flask
    const consultas = await obterConsultas();
    
    // 3. Filtrar apenas consultas ativas
    const ativas = consultas.filter(c => c.estado !== "cancelada" && c.estado !== "realizada");

    // 4. Agrupar e normalizar as prioridades
    const porPrioridade = {
        urgente: ativas.filter(c => (c.prioridade || "").toLowerCase().trim() === "urgente"),
        alta: ativas.filter(c => (c.prioridade || "").toLowerCase().trim() === "alta"),
        media: ativas.filter(c => (c.prioridade || "").toLowerCase().trim() === "media"),
        baixa: ativas.filter(c => !(c.prioridade) || (c.prioridade || "").toLowerCase().trim() === "baixa")
    };

    // 5. Atualizar os contadores visuais do topo
    if (document.getElementById("contadorUrgente")) document.getElementById("contadorUrgente").innerText = porPrioridade.urgente.length;
    if (document.getElementById("contadorAlta")) document.getElementById("contadorAlta").innerText = porPrioridade.alta.length;
    if (document.getElementById("contadorMedia")) document.getElementById("contadorMedia").innerText = porPrioridade.media.length;
    if (document.getElementById("contadorBaixa")) document.getElementById("contadorBaixa").innerText = porPrioridade.baixa.length;

    // 6. Juntar a fila por ordem de gravidade
    const filaOrdenada = [...porPrioridade.urgente, ...porPrioridade.alta, ...porPrioridade.media, ...porPrioridade.baixa];

    // 7. Se a fila estiver vazia
    if (filaOrdenada.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; padding:20px; color:#888;"><i class="fa fa-info-circle"></i> Nenhuma consulta na fila de atendimento ativa.</td></tr>`;
        return;
    }

    // 8. Construção segura na memória
    let linhasHtml = "";

    filaOrdenada.forEach(c => {
        const prioLimpa = (c.prioridade || "baixa").toLowerCase().trim();
        const dataConsulta = c.data ? `${c.data} às ` : "";
        
        linhasHtml += `
            <tr>
                <td><strong>${c.paciente || "Não informado"}</strong></td>
                <td><i class="fa fa-user-md" style="color:#64748b; margin-right:4px;"></i> ${c.medico || "Não atribuído"}</td>
                <td>${c.especialidade || "Geral"}</td>
                <td>${dataConsulta}${c.hora || "--:--"}</td>
                <td>
                    <span class="badge-prioridade prioridade-${prioLimpa}">
                        ${prioLimpa}
                    </span>
                </td>
            </tr>
        `;
    });

    // 9. Injeta de uma só vez
    tbody.innerHTML = linhasHtml;
}